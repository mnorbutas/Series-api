package com.projeto.series.service;

import com.projeto.series.model.Serie;
import com.projeto.series.repository.SerieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SerieService {

    @Autowired
    private SerieRepository repositorio;

    // Listar todas
    public List<Serie> listar() {
        return repositorio.findAll();
    }

    // Salvar ou Atualizar
    public Serie salvar(Serie serie) {
        serie.setTitulo(serie.getTitulo().toUpperCase());
        return repositorio.save(serie);
    }

    // Buscar por ID
    public Optional<Serie> buscarPorId(Long id) {
        return repositorio.findById(id);
    }

    // Deletar
    public void deletar(Long id) {
        repositorio.deleteById(id);
    }
}