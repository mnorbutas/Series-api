package com.projeto.series.controller;

import com.projeto.series.model.Serie;
import com.projeto.series.service.SerieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/series")
@CrossOrigin(origins = "*") 
public class SerieController {

    @Autowired
    private SerieService servico;

    @GetMapping
    public List<Serie> listar() {
        return servico.listar();
    }

    @PostMapping
    public Serie salvar(@RequestBody Serie serie) {
        return servico.salvar(serie);
    }

    @DeleteMapping("/{id}")
    public void excluir(@PathVariable Long id) {
        servico.deletar(id);
    }
}