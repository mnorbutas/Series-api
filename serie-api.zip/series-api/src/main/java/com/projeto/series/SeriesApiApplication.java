package com.projeto.series;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeriesApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeriesApiApplication.class, args);
	}

}
