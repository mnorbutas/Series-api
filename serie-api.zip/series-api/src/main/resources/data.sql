
INSERT INTO tb_serie (titulo, genero) VALUES ('STRANGER THINGS', 'Ficção Científica');
INSERT INTO tb_serie (titulo, genero) VALUES ('THE BOYS', 'Ação');
INSERT INTO tb_serie (titulo, genero) VALUES ('BREAKING BAD', 'Drama');