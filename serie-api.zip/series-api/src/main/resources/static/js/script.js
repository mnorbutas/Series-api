const URL = '/api/series';

async function listar() {
    try {
        const res = await fetch(URL);
        if (!res.ok) throw new Error("Rota não encontrada no Java");
        
        const dados = await res.json();
        const tabela = document.getElementById('listaSeries');
        tabela.innerHTML = '';

        dados.forEach(s => {
            tabela.innerHTML += `
                <tr>
                    <td>${s.titulo}</td>
                    <td>${s.genero}</td>
                    <td><button onclick="excluir(${s.id})">Deletar</button></td>
                </tr>`;
        });
    } catch (err) {
        console.error("Erro ao listar:", err);
    }
}

async function salvar() {
    const titulo = document.getElementById('titulo').value;
    const genero = document.getElementById('genero').value;

    if (!titulo.trim()) {
        alert("O título é obrigatório!");
        return;
    }

    const serie = { titulo, genero };

    const res = await fetch(URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(serie)
    });

    if (res.ok) {
        document.getElementById('titulo').value = '';
        document.getElementById('genero').value = '';
        listar();
    } else {
        alert("Erro ao salvar. Verifique se o Java está rodando.");
    }
}

async function excluir(id) {
    await fetch(`${URL}/${id}`, { method: 'DELETE' });
    listar();
}

listar();